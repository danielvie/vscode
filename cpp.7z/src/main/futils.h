
#ifndef __FUTILS__
#define __FUTILS__

#include <cmath>
#include <string>

#define PI 3.1415926535897932384

struct RET_utm {
    double e;
    double n;
    int z;
    std::string h;
};

struct RET_deg {
    double lat;
    double lon;    
};

struct RET_utm deg2utm(double Lat, double Lon);
struct RET_deg utm2deg(double xx, double yy, int utmzone, std::string hemis);

#endif // __FUTILS__
