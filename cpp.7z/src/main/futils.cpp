#include "futils.h"

struct RET_utm deg2utm(double Lat, double Lon) {

    // -------------------------------------------------------------------------
    // [x,y,utmzone] = deg2utm(Lat,Lon)
    //
    // Description: Function to convert lat/lon vectors into UTM coordinates (WGS84).
    // Some code has been extracted from UTM.m function by Gabriel Ruiz Martinez.
    //
    // Inputs:
    //    Lat: Latitude vector.   Degrees.  +ddd.ddddd  WGS84
    //    Lon: Longitude vector.  Degrees.  +ddd.ddddd  WGS84
    //
    // Outputs:
    //    x, y , utmzone.   See example
    //
    // Example 1:
    //    Lat=[40.3154333; 46.283900; 37.577833; 28.645650; 38.855550; 25.061783];
    //    Lon=[-3.4857166; 7.8012333; -119.95525; -17.759533; -94.7990166; 121.640266];
    //    [x,y,utmzone] = deg2utm(Lat,Lon);
    //    fprintf('%7.0f ',x)
    //       458731  407653  239027  230253  343898  362850
    //    fprintf('%7.0f ',y)
    //      4462881 5126290 4163083 3171843 4302285 2772478
    //    utmzone =
    //       30 T
    //       32 T
    //       11 S
    //       28 R
    //       15 S
    //       51 R
    //
    // Example 2: If you have Lat/Lon coordinates in Degrees, Minutes and Seconds
    //    LatDMS=[40 18 55.56; 46 17 2.04];
    //    LonDMS=[-3 29  8.58;  7 48 4.44];
    //    Lat=dms2deg(mat2dms(LatDMS)); %convert into degrees
    //    Lon=dms2deg(mat2dms(LonDMS)); %convert into degrees
    //    [x,y,utmzone] = deg2utm(Lat,Lon)
    //
    // Author:
    //   Rafael Palacios
    //   Universidad Pontificia Comillas
    //   Madrid, Spain
    // Version: Apr/06, Jun/06, Aug/06, Aug/06
    // Aug/06: fixed a problem (found by Rodolphe Dewarrat) related to southern
    //    hemisphere coordinates.
    // Aug/06: corrected m-Lint warnings
    //-------------------------------------------------------------------------

    double la = Lat;
    double lo = Lon;
    
    double sa = 6378137.000000; 
    double sb = 6356752.314245;
    
    // %e = (((sa^2) - (sb^2))^0.5)/sa;
    double e2 = sqrt(pow(sa,2) - pow(sb,2))/sb;
    double e2cuadrada = pow(e2,2);
    double c = pow(sa,2)/sb;
    
    // %alpha = (sa - sb)/sa;             %f
    // %ablandamiento = 1/alpha;   % 1/f
    
    double lat = la*(PI/180);
    double lon = lo*(PI/180);
    
    double Huso = trunc((lo/6) + 31);
    double S = ((Huso*6) - 183);
    double deltaS = lon - (S*(PI/180));
    
    // if (la<-72), Letra='C';
    // elseif (la<-64), Letra='D';
    // elseif (la<-56), Letra='E';
    // elseif (la<-48), Letra='F';
    // elseif (la<-40), Letra='G';
    // elseif (la<-32), Letra='H';
    // elseif (la<-24), Letra='J';
    // elseif (la<-16), Letra='K';
    // elseif (la<-8), Letra='L';
    // elseif (la<0), Letra='M';
    // elseif (la<8), Letra='N';
    // elseif (la<16), Letra='P';
    // elseif (la<24), Letra='Q';
    // elseif (la<32), Letra='R';
    // elseif (la<40), Letra='S';
    // elseif (la<48), Letra='T';
    // elseif (la<56), Letra='U';
    // elseif (la<64), Letra='V';
    // elseif (la<72), Letra='W';
    // else Letra='X';
    // end
    
    double a       = cos(lat)*sin(deltaS);
    double epsilon = 0.5*log((1 +  a)/(1 - a));
    double nu      = atan(tan(lat)/cos(deltaS)) - lat;

    double v       = c/pow(1 + e2cuadrada*pow(cos(lat),2.0),0.5)*0.9996;

    double ta      = e2cuadrada/2*pow(epsilon,2)*pow(cos(lat),2);
    double a1      = sin(2*lat);
    double a2      = a1*pow(cos(lat),2);
    double j2      = lat + (a1/2);
    double j4      = ((3*j2) + a2)/4;
    double j6      = ((5*j4) + (a2*pow(cos(lat),2)))/3;
    double alfa    = e2cuadrada*3.0/4.0;
    double beta    = pow(alfa,2.0)*5.0/3.0;
    double gama    = pow(alfa,3.0)*35.0/27.0;
    double Bm      = 0.9996*c*(lat - alfa*j2 + beta*j4 - gama*j6);
    double xx      = epsilon*v*(1 + (ta/3)) + 500000;
    double yy      = nu*v*(1 + ta) + Bm;
    
    if (yy<0){
        yy += 9999999.0;
    }
    
    struct RET_utm ret;

    ret.e = xx;
    ret.n = yy;
    ret.z = (int)Huso;
    
    if (la < 0.0) {
        ret.h = "S";
    } 
    else {
        ret.h = "N";
    }
        
    return ret;

}

struct RET_deg utm2deg(double xx, double yy, int utmzone, std::string hemis) {
// -------------------------------------------------------------------------
// [Lat,Lon] = utm2deg(x,y,utmzone)
//
// Description: Function to convert vectors of UTM coordinates into Lat/Lon vectors (WGS84).
// Some code has been extracted from UTMIP.m function by Gabriel Ruiz Martinez.
//
// Inputs:
//    x, y , utmzone.
//
// Outputs:
//    Lat: Latitude vector.   Degrees.  +ddd.ddddd  WGS84
//    Lon: Longitude vector.  Degrees.  +ddd.ddddd  WGS84
//
//  Example 1:
//  x=[ 458731;  407653;  239027;  230253;  343898;  362850];
//  y=[4462881; 5126290; 4163083; 3171843; 4302285; 2772478];
//  utmzone=['30 T'; '32 T'; '11 S'; '28 R'; '15 S'; '51 R'];
//  [Lat, Lon]=utm2deg(x,y,utmzone);
//  fprintf('%11.6f ',lat)
//     40.315430   46.283902   37.577834   28.645647   38.855552   25.061780
//  fprintf('%11.6f ',lon)
//     -3.485713    7.801235 -119.955246  -17.759537  -94.799019  121.640266
// 
//  Example 2: If you need Lat/Lon coordinates in Degrees, Minutes and Seconds
//  [Lat, Lon]=utm2deg(x,y,utmzone);
//  LatDMS=dms2mat(deg2dms(Lat))
// LatDMS =
//     40.00         18.00         55.55
//     46.00         17.00          2.01
//     37.00         34.00         40.17
//     28.00         38.00         44.33
//     38.00         51.00         19.96
//     25.00          3.00         42.41
//  LonDMS=dms2mat(deg2dms(Lon))
// LonDMS =
//     -3.00         29.00          8.61
//      7.00         48.00          4.40
//   -119.00         57.00         18.93
//    -17.00         45.00         34.33
//    -94.00         47.00         56.47
//    121.00         38.00         24.96
// 
//  Author:
//    Rafael Palacios
//    Universidad Pontificia Comillas
//    Madrid, Spain
//  Version: Apr/06, Jun/06, Aug/06
//  Aug/06: corrected m-Lint warnings
// -------------------------------------------------------------------------

    double x = xx;
    double y = yy;
    double zone = (double) utmzone;
    
    double sa = 6378137.000000; 
    double sb = 6356752.314245;
    
    double e2 = sqrt(pow(sa,2) - pow(sb,2))/sb;
    double e2cuadrada = pow(e2,2);
    double c = pow(sa,2)/sb;
        
    double X = x - 500000;
    double Y;

    if ((hemis.compare("S") == 0) || (hemis.compare("s") == 0)){
        Y = y - 10000000;
    }
    else {
        Y = y;
    }
    
    double S = ((zone*6) - 183);
    double lat =  Y/(6366197.724*0.9996);
    // double v = sqrt(c/(1 + e2cuadrada*pow(cos(lat),2)))*0.9996;
    // double v = ( c / sqrt( ( 1 + ( e2cuadrada * ( cos(lat), 2) ) ) ) ) * 0.9996;
    // double v = (c/sqrt(1.0+(e2cuadrada*cos(lat)*cos(lat))))*0.9996;

    double v   = c/sqrt(1 + e2cuadrada*cos(lat)*cos(lat))*0.9996;

    double a = X/v;
    double a1 = sin(2*lat);
    double a2 = a1*pow(cos(lat),2);
    double j2 = lat + (a1/2);
    double j4 = ((3*j2) + a2)/4;
    double j6 = ((5*j4) + (a2*pow(cos(lat),2)))/3;
    double alfa = e2cuadrada*3.0/4.0;
    double beta = pow(alfa,2)*5.0/3.0;
    double gama = pow(alfa,3)*35.0/27.0;
    double Bm = 0.9996*c*(lat - alfa*j2 + beta*j4 - gama*j6);
    double b = (Y - Bm)/v;
    // double Epsi = ((e2cuadrada*pow(a,2))/2)*pow(cos(lat),2);
    double Epsi = ( ( e2cuadrada * pow(a,2) ) / 2 ) * pow( cos(lat) ,2);
    double Eps = a*(1 - (Epsi/3));
    double nab = (b*(1 - Epsi)) + lat;
    double senoheps = (exp(Eps) - exp(-Eps))/2;
    double Delt = atan(senoheps/(cos(nab)));
    double TaO = atan(cos(Delt)*tan(nab));
    double longitude = Delt*180.0/PI + S;
    double latitude = (lat + (1.0 + e2cuadrada* pow(cos(lat),2) - (3/2)*e2cuadrada*sin(lat)*cos(lat)*(TaO - lat))*(TaO - lat))*180/PI;
    
    // Lat(i)=latitude;
    // Lon(i)=longitude;
    
    struct RET_deg ret;
    ret.lat = latitude;
    ret.lon = longitude;

    return ret;
}