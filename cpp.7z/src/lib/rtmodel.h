#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_

#include "mod_foggui.h"
#define GRTINTERFACE                   0

# define ROOT_IO_FORMAT                2
#define MODEL_CLASSNAME                mod_fogguiModelClass
#define MODEL_STEPNAME                 step
#endif
