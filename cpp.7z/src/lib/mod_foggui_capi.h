#ifndef RTW_HEADER_mod_foggui_capi_h
#define RTW_HEADER_mod_foggui_capi_h
#include "mod_foggui.h"

extern void mod_foggui_InitializeDataMapInfo(RT_MODEL_mod_foggui_T *const
  mod_foggui_M, B_mod_foggui_T *mod_foggui_B, P_mod_foggui_T *mod_foggui_P,
  DW_mod_foggui_T *mod_foggui_DW);

#endif

