#ifndef __PYUTILS__
#define __PYUTILS__

#include <string>
#include <vector>
#include <algorithm>

#include <Python.h>
#include <numpy/arrayobject.h>
#include <numpy/arrayscalars.h>
#include <numpy/numpyconfig.h>

struct S_atmos {
    double temperatura;
    double temperatura_prop;
    double pressao;
};

std::string py2string(PyObject* o);
std::vector<double> get_vetor_double(PyObject* array);
std::vector<std::string> get_vetor_string(PyObject* array);
std::string repmat_py(int nro, std::string matriz);

int check_vetor_float(PyObject* value);
struct S_atmos fn_set_atmos_(float h);

#endif // __PYUTILS__
