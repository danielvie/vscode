/*
 * pextension.cpp
 *
 *  Created on: 13 de dez de 2018
 *      Author: dvieira
 */

#include <Python.h>
#include "mod_foggui.h"
#include <vector>
#include <numpy/arrayobject.h>

#include <cstdio>
#include <map>
#include <cstring>
#include "py_utils.h"


#include <algorithm>
#include <string>
#include <iostream>

PyObject *set_data(PyObject *self, PyObject *args);
PyObject *get_data(PyObject *self, PyObject *args);

PyObject *initialize(PyObject *self, PyObject *args);
PyObject *step(PyObject *self, PyObject *args);
PyObject *run(PyObject *self, PyObject *args);
PyObject *terminate(PyObject *self, PyObject *args);
PyObject *start(PyObject *self, PyObject *args);
PyObject *get_fim(PyObject *self, PyObject *args);


mod_fogguiModelClass *fg;

PyMethodDef SpamMethods[] = {
    {"init", (PyCFunction)initialize, METH_VARARGS, 0},
    {"initialize", (PyCFunction)initialize, METH_VARARGS, 0},
    {"step", (PyCFunction)step, METH_VARARGS, 0},
    {"run", (PyCFunction)run, METH_VARARGS, 0},
    {"terminate", (PyCFunction)terminate, METH_VARARGS, 0},
    {"start", (PyCFunction)start, METH_VARARGS, 0},
	{"get_fim", (PyCFunction)get_fim, METH_VARARGS, 0},
    {"set_data", (PyCFunction)set_data, METH_VARARGS, 0},
    {"get_data", (PyCFunction)get_data, METH_VARARGS, 0},
	{0, 0, 0, 0}
};

static struct PyModuleDef spammodule = {
    PyModuleDef_HEAD_INIT,
    "fg_engine",
    "modulo de simulacao SS40G",
    -1,
    SpamMethods
};

PyMODINIT_FUNC PyInit_fg_engine(void) {

    fg = new mod_fogguiModelClass();
    fg->initialize();

	import_array();
    return PyModule_Create(&spammodule);
}

struct DataMap {
	int idx;
	void *addr;
    const char *name;
    const char *type;
    int size;    
};

struct DataMap get_map_from_datamap(const char *name) {
    struct DataMap datamaps[] {
	    /* lancamento */
        {0, (void *) &fg->mod_foggui_P.state.config.lancamento.Elev, "Elev", "double", 1},
        {1, (void *) &fg->mod_foggui_P.state.config.lancamento.Rlat, "Rlat", "double", 1},
        {2, (void *) &fg->mod_foggui_P.state.config.lancamento.Rlong, "Rlong", "double", 1},
        {3, (void *) &fg->mod_foggui_P.state.config.lancamento.Ralt, "Ralt", "double", 1},
        {4, (void *) &fg->mod_foggui_P.state.config.lancamento.Azi, "Azi", "double", 1},
        {5, (void *) &fg->mod_foggui_P.state.config.lancamento.Talt, "Talt", "double", 1},
        {6, (void *) &fg->mod_foggui_P.state.config.lancamento.Tesp, "Tesp", "double", 1},
        {7, (void *) &fg->mod_foggui_P.state.config.lancamento.Hsub, "Hsub", "double", 1},
        {8, (void *) &fg->mod_foggui_P.state.config.lancamento.Hmet, "Hmet", "double", 1},
        {9, (void *) &fg->mod_foggui_P.state.config.lancamento.Rtemp, "Rtemp", "double", 1},
        {10, (void *) &fg->mod_foggui_P.state.config.lancamento.Rde, "Rde", "double", 1},
        {11, (void *) &fg->mod_foggui_P.state.config.lancamento.Dbal, "Dbal", "double", 1},
        {12, (void *) &fg->mod_foggui_P.state.config.lancamento.Tbal, "Tbal", "double", 1},
        {13, (void *) &fg->mod_foggui_P.state.config.lancamento.Pbal, "Pbal", "double", 1},
        {14, (void *) &fg->mod_foggui_P.state.config.lancamento.Phi0, "Phi0", "double", 1},
        /* inercia */
        {15, (void *) &fg->mod_foggui_P.state.config.inercia.Mf, "Mf", "double", 1},
        {16, (void *) &fg->mod_foggui_P.state.config.inercia.Xf, "Xf", "double", 1},
        {17, (void *) &fg->mod_foggui_P.state.config.inercia.Yf, "Yf", "double", 1},
        {18, (void *) &fg->mod_foggui_P.state.config.inercia.Zf, "Zf", "double", 1},
        {19, (void *) &fg->mod_foggui_P.state.config.inercia.Ixf, "Ixf", "double", 1},
        {20, (void *) &fg->mod_foggui_P.state.config.inercia.Iyf, "Iyf", "double", 1},
        {21, (void *) &fg->mod_foggui_P.state.config.inercia.Izf, "Izf", "double", 1},
        {22, (void *) &fg->mod_foggui_P.state.config.inercia.Ixyf, "Ixyf", "double", 1},
        {23, (void *) &fg->mod_foggui_P.state.config.inercia.Ixzf, "Ixzf", "double", 1},
        {24, (void *) &fg->mod_foggui_P.state.config.inercia.Iyzf, "Iyzf", "double", 1},
        {25, (void *) &fg->mod_foggui_P.state.config.inercia.Fgrot, "Fgrot", "double", 1},
        {26, (void *) &fg->mod_foggui_P.state.config.inercia.Fog, "Fog", "double", 1},
        {27, (void *) &fg->mod_foggui_P.state.config.inercia.Ixemp_fech, "Ixemp_fech", "double", 1},
        {28, (void *) &fg->mod_foggui_P.state.config.inercia.Kc, "Kc", "double", 1},
        {29, (void *) &fg->mod_foggui_P.state.config.inercia.Tabin, "Tabin", "double", 1},
        {30, (void *) &fg->mod_foggui_P.state.config.inercia.Tabre, "Tabre", "double", 1},
        {31, (void *) &fg->mod_foggui_P.state.config.inercia.A2, "A2", "double", 1},
        {32, (void *) &fg->mod_foggui_P.state.config.inercia.A5, "A5", "double", 1},
        {33, (void *) &fg->mod_foggui_P.state.config.inercia.A9, "A9", "double", 1},
        {34, (void *) &fg->mod_foggui_P.state.config.inercia.A10, "A10", "double", 1},
        /* propelente */
        {35, (void *) &fg->mod_foggui_P.state.config.propelente.Mp0, "Mp0", "double", 1},
        {36, (void *) &fg->mod_foggui_P.state.config.propelente.Xp, "Xp", "double", 1},
        {37, (void *) &fg->mod_foggui_P.state.config.propelente.Yp, "Yp", "double", 1},
        {38, (void *) &fg->mod_foggui_P.state.config.propelente.Zp, "Zp", "double", 1},
        {39, (void *) &fg->mod_foggui_P.state.config.propelente.Ixyp, "Ixyp", "double", 1},
        {40, (void *) &fg->mod_foggui_P.state.config.propelente.Ixzp, "Ixzp", "double", 1},
        {41, (void *) &fg->mod_foggui_P.state.config.propelente.Iyzp, "Iyzp", "double", 1},
        {42, (void *) &fg->mod_foggui_P.state.config.propelente.Dp, "Dp", "double", 1},
        {43, (void *) &fg->mod_foggui_P.state.config.propelente.Lp, "Lp", "double", 1},
        {44, (void *) &fg->mod_foggui_P.state.config.propelente.Rop, "Rop", "double", 1},
        {45, (void *) &fg->mod_foggui_P.state.config.propelente.Tb0, "Tb0", "double", 1},
        {46, (void *) &fg->mod_foggui_P.state.config.propelente.T_trans, "T_trans", "double", 1},
        {47, (void *) &fg->mod_foggui_P.state.config.propelente.E0, "E0", "double", 1},
        {48, (void *) &fg->mod_foggui_P.state.config.propelente.Ye, "Ye", "double", 1},
        {49, (void *) &fg->mod_foggui_P.state.config.propelente.Ze, "Ze", "double", 1},
        {50, (void *) &fg->mod_foggui_P.state.config.propelente.Alfaj, "Alfaj", "double", 1},
        {51, (void *) &fg->mod_foggui_P.state.config.propelente.Betaj, "Betaj", "double", 1},
        {52, (void *) &fg->mod_foggui_P.state.config.propelente.Ae, "Ae", "double", 1},
        {53, (void *) &fg->mod_foggui_P.state.config.propelente.Grot0, "Grot0", "double", 1},
        {54, (void *) &fg->mod_foggui_P.state.config.propelente.Kcan, "Kcan", "double", 1},
        /* geometria */
        {55, (void *) &fg->mod_foggui_P.state.config.geometria.Dr, "Dr", "double", 1},
        {56, (void *) &fg->mod_foggui_P.state.config.geometria.Lb, "Lb", "double", 1},
        {57, (void *) &fg->mod_foggui_P.state.config.geometria.Be, "Be", "double", 1},
        {58, (void *) &fg->mod_foggui_P.state.config.geometria.Ce, "Ce", "double", 1},
        {59, (void *) &fg->mod_foggui_P.state.config.geometria.Fe, "Fe", "double", 1},
        {60, (void *) &fg->mod_foggui_P.state.config.geometria.De0, "De0", "double", 1},
        {61, (void *) &fg->mod_foggui_P.state.config.geometria.Flat, "Flat", "double", 1},
        {62, (void *) &fg->mod_foggui_P.state.config.geometria.Fnor, "Fnor", "double", 1},
        {63, (void *) &fg->mod_foggui_P.state.config.geometria.Retemp, "Retemp", "double", 1},
        {64, (void *) &fg->mod_foggui_P.state.config.geometria.Wabre, "Wabre", "double", 1},
        {65, (void *) &fg->mod_foggui_P.state.config.geometria.Dalfog0, "Dalfog0", "double", 1},
        /* dados_part */
        {66, (void *) &fg->mod_foggui_P.state.config.dados_part.Xt1, "Xt1", "double", 1},
        {67, (void *) &fg->mod_foggui_P.state.config.dados_part.Xt2, "Xt2", "double", 1},
        {68, (void *) &fg->mod_foggui_P.state.config.dados_part.Xt3, "Xt3", "double", 1},
        {69, (void *) &fg->mod_foggui_P.state.config.dados_part.Xfim, "Xfim", "double", 1},
        {70, (void *) &fg->mod_foggui_P.state.config.dados_part.Dlan, "Dlan", "double", 1},
        {71, (void *) &fg->mod_foggui_P.state.config.dados_part.Ktubo, "Ktubo", "double", 1},
        {72, (void *) &fg->mod_foggui_P.state.config.dados_part.Rt, "Rt", "double", 1},
        {73, (void *) &fg->mod_foggui_P.state.config.dados_part.Lr, "Lr", "double", 1},
        {74, (void *) &fg->mod_foggui_P.state.config.dados_part.Mir, "Mir", "double", 1},
        {75, (void *) &fg->mod_foggui_P.state.config.dados_part.Xboca, "Xboca", "double", 1},
        {76, (void *) &fg->mod_foggui_P.state.config.dados_part.Memp, "Memp", "double", 1},
        {77, (void *) &fg->mod_foggui_P.state.config.dados_part.Cemp, "Cemp", "double", 1},
        {78, (void *) &fg->mod_foggui_P.state.config.dados_part.Demp, "Demp", "double", 1},
        {79, (void *) &fg->mod_foggui_P.state.config.dados_part.Aemp, "Aemp", "double", 1},
        {80, (void *) &fg->mod_foggui_P.state.config.dados_part.Cemp0, "Cemp0", "double", 1},
        {81, (void *) &fg->mod_foggui_P.state.config.dados_part.Cemp1, "Cemp1", "double", 1},
        {82, (void *) &fg->mod_foggui_P.state.config.dados_part.Cemp2, "Cemp2", "double", 1},
        {83, (void *) &fg->mod_foggui_P.state.config.dados_part.Cemp3, "Cemp3", "double", 1},
        {84, (void *) &fg->mod_foggui_P.state.config.dados_part.Ixemp, "Ixemp", "double", 1},
        {85, (void *) &fg->mod_foggui_P.state.config.dados_part.Fcdsub, "Fcdsub", "double", 1},
        {86, (void *) &fg->mod_foggui_P.state.config.dados_part.Dsub, "Dsub", "double", 1},
        {87, (void *) &fg->mod_foggui_P.state.config.dados_part.Msub, "Msub", "double", 1},
        {88, (void *) &fg->mod_foggui_P.state.config.dados_part.Xac, "Xac", "double", 1},
        {89, (void *) &fg->mod_foggui_P.state.config.dados_part.Yac, "Yac", "double", 1},
        {90, (void *) &fg->mod_foggui_P.state.config.dados_part.Zac, "Zac", "double", 1},
        /* flags */
        {91, (void *) &fg->mod_foggui_P.state.config.flags.controle_on, "flag/controle_on", "double", 1},
        /* dados empuxo */
        {92, (void *) &fg->mod_foggui_P.state.config.dados_empuxo.Tempo[0], "empuxo/Tempo", "double", 41},
        {93, (void *) &fg->mod_foggui_P.state.config.dados_empuxo.Empuxo[0], "empuxo/Empuxo", "double", 41},
        {94, (void *) &fg->mod_foggui_P.state.config.dados_empuxo.Grot[0], "empuxo/Grot", "double", 41},
        /* controle */
        {95, (void *) &fg->mod_foggui_P.state.controle.alvo[0], "controle/alvo", "double", 3},        
        {96, (void *) &fg->mod_foggui_P.state.controle.dh_alvo, "controle/dh_alvo", "double", 1},
        {97, (void *) &fg->mod_foggui_P.state.controle.t_canard, "controle/t_canard", "double", 1},
        {98, (void *) &fg->mod_foggui_P.state.controle.cd_subm, "controle/cd_subm", "double", 1},
        {99, (void *) &fg->mod_foggui_P.state.controle.ganhos[0], "controle/ganhos", "double", 10},
        /* dados vento */
        {100, (void *) &fg->mod_foggui_P.state.config.dados_vento.altitude[0], "vento/altitude", "double", 48},
        {101, (void *) &fg->mod_foggui_P.state.config.dados_vento.azimute[0], "vento/azimute", "double", 48},
        {102, (void *) &fg->mod_foggui_P.state.config.dados_vento.velocidade[0], "vento/velocidade", "double", 48},
        {-1, NULL, NULL, NULL, 0}
    };

    int cont = 0;
	struct DataMap map = {-1, NULL, NULL, NULL, 0};
	while (datamaps[cont].addr != NULL) {
        if (strcmp(datamaps[cont].name, name) == 0) {
            map = datamaps[cont];
            break;
        }
        cont++;
    }
	
	// se nao encontrar, retornar estrutura NULL
	return map;
}

int set_value_to_datamap( const char *name, void *addr, int len ) {
	
	// declarando variaveis
	int ret = -1;

	// encontrando 'idx'
	struct DataMap map = get_map_from_datamap(name);

	// printf("name: %s\n", map.name);
	if (map.addr != NULL){
		if (strcmp(map.type, "double") == 0) {
			memset(map.addr, 0, map.size*sizeof(double));
			memcpy(map.addr, addr, len*sizeof(double));
		} else if (strcmp(map.type, "int") == 0) {
			memset(map.addr, 0, map.size*sizeof(int));
			memcpy(map.addr, addr, len*sizeof(int));
		}
	}

	return ret;
}

PyObject* set_data(PyObject* self, PyObject* args) {

    const char *name;

    PyObject* value;
    double valor_d;
    int valor_i;
    std::vector<double> vetor;
    
    int len;
    
    if (!PyArg_ParseTuple(args, "sO", &name, &value)) {
        return NULL;
    }

	struct DataMap map = get_map_from_datamap(name);

    int islist = PyList_Check(value);
    len = 1;
    if (islist) {
        len = PySequence_Fast_GET_SIZE(value);
    }

    if (map.addr != NULL) {
        if (map.size == 1){
            // escalar
            valor_d = PyFloat_AsDouble(value);
            if (strcmp(map.type, "int") == 0) {
                valor_i = (int)valor_d;
                set_value_to_datamap(name, (void *) &valor_i, 1);
            } else {
                set_value_to_datamap(name, (void *) &valor_d, 1);
            }
        } else {
            // vetor
            vetor = get_vetor_double(value);
            set_value_to_datamap(name, (void *) vetor.data(), len);
        }
    }

    return Py_BuildValue("i",1);
}

PyArrayObject* create_nparray_double(double data[], int len) {
    
    int ndims = 1;
    npy_intp dims[1] = {len};
    PyArrayObject *np_array = (PyArrayObject*)PyArray_SimpleNew(ndims, dims, NPY_DOUBLE);

    memcpy(PyArray_DATA(np_array), data, sizeof(double) * len);

    return np_array;
}

PyObject* get_data(PyObject* self, PyObject* args) {

    const char *name;
    std::vector<double> vetor;
    int i;

    if (!PyArg_ParseTuple(args, "s", &name)) {
        return NULL;
    }

	struct DataMap map = get_map_from_datamap(name);

    // se o mapa foi encontrado
    if (map.addr != NULL){
        if (map.size == 1) {
            // escalar
            if (strcmp(map.type, "double") == 0) {
                // double
                return Py_BuildValue("d",*(double *)map.addr);
            }
            if (strcmp(map.type, "int") == 0) {
                // int
                return Py_BuildValue("i",*(int *)map.addr);
            }
        } else {
            // vetor double
            for (i = 0; i < map.size; i++){
                vetor.push_back(*((double *)map.addr + i));
            }
            return Py_BuildValue("N", create_nparray_double(vetor.data(), map.size));
        }
    }
    
    return Py_BuildValue("i", -1);
}

PyObject *initialize(PyObject *self, PyObject *args) {
    fg = new mod_fogguiModelClass();

    fg->initialize();
    fg->mod_foggui_P.state.config.flags.controle_on = 1;

    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }
    return Py_BuildValue("");
}

PyObject *step(PyObject *self, PyObject *args) {
    fg->step();

    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }

    return Py_BuildValue("");
}

PyObject *run(PyObject *self, PyObject *args) {

    int len;
    std::map<std::string, std::vector<double>> voo;
    
    int i, nro_log;
    std::string txt = "";

    while (fg->mod_foggui_Y.fim == 0) {
        fg->step();

        voo["t"].push_back(fg->mod_foggui_Y.tempo);
        voo["x"].push_back(fg->mod_foggui_Y.pos[0]);
        voo["y"].push_back(fg->mod_foggui_Y.pos[1]);
        voo["z"].push_back(fg->mod_foggui_Y.pos[2]);
        voo["vx"].push_back(fg->mod_foggui_Y.vel[0]);
        voo["vy"].push_back(fg->mod_foggui_Y.vel[1]);
        voo["vz"].push_back(fg->mod_foggui_Y.vel[2]);
        voo["phi"].push_back(fg->mod_foggui_Y.ang[0]);
        voo["theta"].push_back(fg->mod_foggui_Y.ang[1]);
        voo["psi"].push_back(fg->mod_foggui_Y.ang[2]);
        voo["u"].push_back(fg->mod_foggui_Y.uvw[0]);
        voo["v"].push_back(fg->mod_foggui_Y.uvw[0]);
        voo["w"].push_back(fg->mod_foggui_Y.uvw[0]);
        voo["p"].push_back(fg->mod_foggui_Y.pqr[0]);
        voo["q"].push_back(fg->mod_foggui_Y.pqr[1]);
        voo["r"].push_back(fg->mod_foggui_Y.pqr[2]);
        voo["acelx"].push_back(fg->mod_foggui_Y.acel[0]);
        voo["acely"].push_back(fg->mod_foggui_Y.acel[1]);
        voo["acelz"].push_back(fg->mod_foggui_Y.acel[2]);
        voo["lat"].push_back(fg->mod_foggui_Y.latlong[0]);
        voo["lon"].push_back(fg->mod_foggui_Y.latlong[1]);
        voo["canard_on"].push_back(fg->mod_foggui_Y.canard_on);
        voo["canard_u1"].push_back(fg->mod_foggui_Y.canard_u[0]);
        voo["canard_u2"].push_back(fg->mod_foggui_Y.canard_u[1]);
        voo["canard_y1"].push_back(fg->mod_foggui_Y.canard_y[0]);
        voo["canard_y2"].push_back(fg->mod_foggui_Y.canard_y[1]);        
        
    }
    
    // montando array canard
    
    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }

    nro_log = 26;
    txt.append("{");
    for (i = 0; i < nro_log; i++){
        txt.append(",s:N");
    }
    txt.append("}");

    len = voo["t"].size();
    return Py_BuildValue(txt.c_str(), 
                          "t", create_nparray_double(voo["t"].data(), len), 
                          "x", create_nparray_double(voo["x"].data(), len),
                          "y", create_nparray_double(voo["y"].data(), len),
                          "z", create_nparray_double(voo["z"].data(), len),
                          "vx", create_nparray_double(voo["vx"].data(), len),
                          "vy", create_nparray_double(voo["vy"].data(), len),
                          "vz", create_nparray_double(voo["vz"].data(), len),
                          "phi", create_nparray_double(voo["phi"].data(), len),
                          "theta", create_nparray_double(voo["theta"].data(), len),
                          "psi", create_nparray_double(voo["psi"].data(), len),
                          "u", create_nparray_double(voo["u"].data(), len),
                          "v", create_nparray_double(voo["v"].data(), len),
                          "w", create_nparray_double(voo["w"].data(), len),
                          "p", create_nparray_double(voo["p"].data(), len),
                          "q", create_nparray_double(voo["q"].data(), len),
                          "r", create_nparray_double(voo["r"].data(), len),
                          "acelx", create_nparray_double(voo["acelx"].data(), len),
                          "acely", create_nparray_double(voo["acely"].data(), len),
                          "acelz", create_nparray_double(voo["acelz"].data(), len),
                          "lat", create_nparray_double(voo["lat"].data(), len),
                          "lon", create_nparray_double(voo["lon"].data(), len),
                          "canard_on", create_nparray_double(voo["canard_on"].data(), len),
                          "canard_u1", create_nparray_double(voo["canard_u1"].data(), len),
                          "canard_u2", create_nparray_double(voo["canard_u2"].data(), len),
                          "canard_y1", create_nparray_double(voo["canard_y1"].data(), len),
                          "canard_y2", create_nparray_double(voo["canard_y2"].data(), len)
                        );
}

PyObject *terminate(PyObject *self, PyObject *args) {
    fg->terminate();

    delete fg;

    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }

    return Py_BuildValue("");
}

PyObject *start(PyObject *self, PyObject *args) {

    fg->mod_foggui_U.tiro = 1;

    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }

    return Py_BuildValue("");
}

PyObject *get_fim(PyObject *self, PyObject *args) {
    int fim;

    fim = fg->mod_foggui_Y.fim;

    if (!PyArg_ParseTuple(args, "")) {
        return NULL;
    }

    return Py_BuildValue("i", fim);
}
