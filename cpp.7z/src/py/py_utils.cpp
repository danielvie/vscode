#include "py_utils.h"

std::string py2string(PyObject* o) {
    // declarando variaveis
    PyObject* repr;
    PyObject* str;
    std::string out;
    unsigned int i;

    // lendo valores
    repr = PyObject_Repr(o);
    str  = PyUnicode_AsEncodedString(repr, "utf-8", "~E~");
    out  = PyBytes_AS_STRING(str);

    // removendo aspas simples dos valores de "'"
    for (i = 0; i < out.length(); ++i) {
        out.erase(std::remove(out.begin(), out.end(), '\''), out.end());
    }

    // retornando string
    return out;
}

std::vector<double> get_vetor_double(PyObject* array) {
    PyObject* item;
    int seqlen;
    int i;

    std::vector<double> array_o;

    /* conferencia se array eh iteravel */
    array = PySequence_Fast(array, "argument must be iterable");

    /* prepare data as an array of doubles */
    seqlen = PySequence_Fast_GET_SIZE(array);

    double valor;
    for (i = 0; i < seqlen; i++) {
        item = PySequence_Fast_GET_ITEM(array, i);
        valor = PyFloat_AsDouble(item);

        array_o.push_back(valor);
    }

    return array_o;
}

int check_vetor_float(PyObject* value) {
    int seqlen;
    int res;
    PyObject* item;

    value = PySequence_Fast(value, "argument must be iterable");
    seqlen = PySequence_Fast_GET_SIZE(value);
    item = PySequence_Fast_GET_ITEM(value, 0);

    res = PyFloat_Check(item);
    return res;
}

std::vector<std::string> get_vetor_string(PyObject* array) {
    PyObject* item;
    int seqlen;
    int i;
    std::vector<std::string> array_o;

    /* argument must be iterable */
    array = PySequence_Fast(array, "argument must be iterable");

    /* prepare data as an array of strings */
    seqlen = PySequence_Fast_GET_SIZE(array);

    std::string valor;
    for (i = 0; i < seqlen; i++) {
        item = PySequence_Fast_GET_ITEM(array, i);
        valor = py2string(item);
        array_o.push_back(valor.c_str());
    }

    return array_o;
}

std::string repmat_py(int nro, std::string matriz) {
    std::string txt = "";
    int i;
    txt.append("{");
    for (i = 0; i < nro; i++){
        txt.append(",");
        txt.append(matriz);
    }
    txt.append("}");

    return txt;
}

struct S_atmos fn_set_atmos_(float h) {
    float g = 9.80665;
    float gamma = 1.4;
    float R = 287.0531;
    float L = 0.0065;
    float hts = 11000;
    float htp = 20000;
    float rho0 = 1.225;
    float P0 = 101325;
    float T0 = 288.15;

    float H0 = 0;

    float T, expon;
    float a, theta, P, rho;

    struct S_atmos res;

    if (h > htp) {
        h = htp;
    }

    if (h < H0) {
        h = H0;
    }

    if (h > hts) {
        T = T0 - L * hts;
        expon = exp(g / (R * T) * (hts - h));
    } else {
        T = T0 - L * h;
        expon = 1.0;
    }

    a = sqrt(T * gamma * R);

    theta = T / T0;

    P = P0 * pow(theta, (g / (L * R))) * expon;
    rho = rho0 * pow(theta, ((g / (L * R)) - 1.0f)) * expon;

    T = T - 273.15;
    P = P / 100.0;

    res.temperatura      = T;
    res.temperatura_prop = T;
    res.pressao          = P;
    
    return res;
}