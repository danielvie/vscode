import fg
import matplotlib.pyplot as plt
import pandas as pd

if __name__ == '__main__':

    state = {
        "lancamento": {
            'Elev': 378.375244140625,
            'Rlat': -0.2733591210586,
            'Rlong': -0.824942547214116,
            'Ralt': 991,
            'Azi': 2924.61759663686,
            'Talt': 971,
            'Tesp': 1e+95,
            'Hsub': 0,
            'Hmet': 991,
            'Rtemp': 25.3,
            'Rde': 1.05623207147754,
            'Dbal': 1,
            'Tbal': 1,
            'Pbal': 1,
            'Phi0': 0
        },
        "ganhos": {
            "ganho1": 0.9, "ganho2": 500.0, "ganho3": 0.0, "ganho4": 0.0,
            "ganho5": 0.0,  # percentual GPS
            "ganho6": 0.0,  # ajuste de precessao
            "ganho7": 0.0, "ganho8": 0.0, "ganho9": 0.0,
            "ganho10": 0.0,  # limitador Wx
        },
        "alvo": {
            "lat": -15.8524325429056,
            "lon": -47.2058613279822,
            "alt": 971.0,
        }
    }
    
    state['ganhos']['ganho3'] = 0.0  # idx
    state['ganhos']['ganho4'] = 0.0  # [0,6] N_lon
    state['ganhos']['ganho5'] = 0.0  # [0,6] N_lon
    state['ganhos']['ganho6'] = 0.0  # [0,6] Ka
    state['ganhos']['ganho7'] = 0.0  # [0,6] Kw
    state['ganhos']['ganho8'] = 0.0
    state['ganhos']['ganho9'] = 0.0
    state['ganhos']['ganho10'] = 0.0
    
    mils = 0.05625
    state['lancamento']['Elev'] = state['lancamento']['Elev'] +1/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] + 1/mils
    
    
    fg.init()
    fg.setLancamento(state)
    fg.setGanhos(state)
    fg.setAlvo(state)    
    fg.start()
    
    
    lat  = 0.0
    lon  = 0.0
    can  = []
    deg  = 180.0/3.1415926535897932384
    
    while not fg.getFim():
        # passo de simulacao
        o = fg.stepLog()
    
        # posicao
        lat = o['lat']
        lon = o['lon']
    
        #  canard
        t = o['t']
        u = o['canard_u1']*deg
        y = o['canard_y1']*deg
    
        # print(t, u)
        can.append([t,u,y])
#        if u != 0.0:
    
    c = pd.DataFrame(can, columns=['t', 'u', 'y'])
    
    plt.plot(c.t,c.u)
    plt.plot(c.t,c.y)
