# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:47:47 2019

@author: dvieira
"""
import fg
import numpy as np
import pandas as pd

def rodaCusto_helper(state):
    fg.init()
    fg.setLancamento(state)
    fg.setGanhos(state)
    fg.setAlvo(state)    
    fg.start()
    
    lat  = 0.0
    lon  = 0.0
    can  = []
    deg  = 180.0/3.1415926535897932384

    
    while not fg.getFim():
        # passo de simulacao
        o = fg.stepLog()

        # posicao
        lat = o['lat']
        lon = o['lon']

        #  canard
        t = o['t']
        u = o['canard_u1']*deg
        
        if u != 0.0:
            can.append([t,u])
    
    # transformando em dataframe
    can  = pd.DataFrame(can, columns=['t','u'])
    
    # mantendo apenas ultimos 10 segundos apenas
    dfim = can.t.values[-1]
    can  = can[can.t > (dfim - 10.0)]
    
    # calculo rms (rad)
    rms_canard = 0.0
    for u in can.u:
        rms_canard += u**2/deg
    
    rms_canard = np.sqrt(rms_canard/len(can.u))
    
    # print("erro_lon: {:.2f}".format(erro_lon))
    # print("rms_can : {:.2f}".format(rms_canard))


    alvo = fg.getControle()['alvo']
    raio_terra = 6371000
    
    # distancia alvo
    dist_lat = (lat - alvo['lat']*np.pi/180.0)*raio_terra
    dist_lon = (lon - alvo['lon']*np.pi/180.0)*raio_terra


    # custo total
    custo = dist_lat**2 + dist_lon**2 + rms_canard**2

    return custo

def rodaCusto(x):
    state = {
        "lancamento": {
            'Elev': 664.85595703125,
            'Rlat': -0.271803721149614,
            'Rlong': -0.824044219837891,
            'Ralt': 973,
            'Azi': 3168.5651826116,
            'Talt': 971,
            'Tesp': 1e+95,
            'Hsub': 0,
            'Hmet': 973,
            'Rtemp': 25.3,
            'Rde': 1.05623207147754,
            'Dbal': 1,
            'Tbal': 1,
            'Pbal': 1,
            'Phi0': 0
        }, 
        "ganhos": {
            "ganho1": 0.9, "ganho2": 500.0, "ganho3": 0.0, "ganho4": 0.0,
            "ganho5": 0.0,  # percentual GPS
            "ganho6": 0.0,  # ajuste de precessao
            "ganho7": 0.0, "ganho8": 0.0, "ganho9": 0.0, 
            "ganho10": 0.0, # limitador Wx
        },
        "alvo": {
            "lat": -15.8524325429056,
            "lon": -47.2058613279822,
            "alt": 971.0,
        }
    }
    
    # penalizando valores fora da regiao
    UPPER = [6.5, 3.0, 3.0, 3.0]
    LOWER = [0.5, 0.5, 0.1, 0.1]
    
    for xi,lo,up in zip(x,LOWER,UPPER):
        if (xi < lo) or (xi > up):
            return 10000000.0

    # calculando custo
    state['ganhos']['ganho3']  = 15.0 # idx
    state['ganhos']['ganho4']  = x[0] # [0,6] N_lon
    state['ganhos']['ganho5']  = x[1] # [0,6] N_lon
    state['ganhos']['ganho6']  = x[2] # [0,6] Ka  
    state['ganhos']['ganho7']  = x[3] # [0,6] Kw
    state['ganhos']['ganho8']  =  0.0 # 
    state['ganhos']['ganho9']  =  0.0 # 
    state['ganhos']['ganho10'] =  0.0 # 
    
    mils = 0.05625

    C = [0,]*4

    state['lancamento']['Elev'] = state['lancamento']['Elev'] + 2.5/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] - 3.0/mils
    C[0] = rodaCusto_helper(state)

    state['lancamento']['Elev'] = state['lancamento']['Elev'] + 2.5/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] + 3.0/mils
    C[1] = rodaCusto_helper(state)

    state['lancamento']['Elev'] = state['lancamento']['Elev'] + 0.5/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] + 3.0/mils
    C[2] = rodaCusto_helper(state)

    state['lancamento']['Elev'] = state['lancamento']['Elev'] + 0.5/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] - 3.0/mils
    C[3] = rodaCusto_helper(state)
    
    # custo = np.sqrt(custo1**2 + custo2**2 + custo3**2 + custo4**2)
    # custo = np.sqrt(custo3**2 + custo4**2)
    # custo = np.sqrt(custo4**2)

    custo = np.sqrt(np.power(C,2).sum())

    return custo
