
import array
import multiprocessing
import random
import numpy
import time

from fn_algoritmo import eaSimple, eaMuCommaLambda, eaMuPlusLambda
from fn_custo import rodaCusto
from fn_salva_hof import salvaHOF

from deap import base, creator, tools

# TYPES
creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
creator.create("Individual", array.array, typecode='f', fitness=creator.FitnessMin)

# INITIALIZATION

#         GUI  GUI  CON  CON
UPPER = [ 6.5, 3.0, 3.0, 3.0]
LOWER = [ 0.5, 0.5, 0.1, 0.1]

nro_variaveis = 4

def uniform(lower_list, upper_list, dimensions):
    if hasattr(lower_list, '__iter__'):
        return [random.uniform(lower,upper) for lower, upper in zip(lower_list,upper_list)]
    else:
        return [random.uniform(lower_list, upper_list) for _ in range(dimensions)]

toolbox = base.Toolbox()
toolbox.register("attribute", uniform, LOWER, UPPER, nro_variaveis)

# toolbox.register("individual", tools.initRepeat, creator.Individual, toolbox.attribute, n=nro_variaveis)
toolbox.register("individual", tools.initIterate, creator.Individual, toolbox.attribute)
toolbox.register("population", tools.initRepeat, list, toolbox.individual)

# OPERATORS
def evaluate(x):
    custo = rodaCusto(x)
    return custo,

toolbox.register("evaluate", evaluate)
toolbox.register("mate", tools.cxTwoPoint)
# toolbox.register("mutate", tools.mutGaussian, mu=0.0, sigma=1.0, indpb=0.2)
toolbox.register("mutate", tools.mutGaussian, mu=0.0, sigma=1.0, indpb=0.2)
toolbox.register("select", tools.selTournament, tournsize=3)

# ALGORITHM
if __name__ == "__main__":
    nro_populacao = 250
    nro_hof       = 20
    nro_geracoes  = 100
    fator_cruzamento = 0.8
    fator_mutacao    = 0.6
    n_workers        = 23
        
    seed = random.randint(0,10000000000)
    random.seed(seed)
    
    # Escrevendo inicio da simulacao
    with open('a_resultado.txt', 'a+') as f:
        barra = lambda x: x.write('-------------------------------------\n')
        # data
        data = time.localtime()
        data_txt = 'data: {:02d}/{:02d}/{:04d}; hora: {:02d}:{:02d}:{:02d}\n'.format(
        data.tm_mday, data.tm_mon, data.tm_year, data.tm_hour, data.tm_min, data.tm_sec)

        f.write('\n')
        barra(f)
        f.write('SIMULACAO\n')
        f.write('seed: {}\n'.format(seed))
        f.write(data_txt)
        barra(f)
        f.write('\n')
                            
    # Process Pool of x workers
    pool = multiprocessing.Pool(n_workers)
    toolbox.register("map", pool.map)
    
    pop = toolbox.population(n=nro_populacao)
    hof = tools.HallOfFame(nro_hof)
    stats = tools.Statistics(lambda ind: ind.fitness.values)
    stats.register("avg", numpy.mean)
    stats.register("std", numpy.std)
    stats.register("min", numpy.min)
    stats.register("max", numpy.max)

    ini = time.time()
    eaSimple(pop, toolbox, cxpb=fator_cruzamento, mutpb=fator_mutacao, ngen=nro_geracoes, stats=stats, halloffame=hof)
    
    # eaMuPlusLambda(pop, toolbox, MU, LAMBDA, cxpb=fator_cruzamento, mutpb=fator_mutacao, ngen=nro_geracoes,
                #    stats=stats, halloffame=hof, verbose=1)

    pool.close()
    tempo = time.strftime('%H:%M:%S',time.gmtime(time.time() - ini))

    print('seed: ',seed)
    print('tempo de simulacao: {}'.format(tempo))
    print(hof[0])
    
    # salvando em txt resultado
    salvaHOF('a_resultado.txt', hof, seed, tempo)
