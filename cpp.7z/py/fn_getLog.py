# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:55:22 2019

@author: dvieira
"""

import fg
import numpy as np
import pandas as pd

def getCampos(o,X):
    v = []
    for x in X:
        v.append(o[x])
    return v

if __name__ == '__main__':
    
    lanc = fg.getLancamento()
    
#    print(lanc)
#    lanc['Elev'] = 400.
#    lanc['Azi'] = 300.
    v = []
    
    cols = ['t', 'lat', 'lon', 'x', 'y', 'z', 'canard_din1']
    
    o = fg.stepLog()
    
    fg.init()
    fg.start()
    while not fg.getFim():
        o = fg.stepLog()
        alc = np.hypot(o['x'],o['y'])
        
        v.append([o[ci] for ci in cols])
        
    d = pd.DataFrame(v,columns=cols)
    d.alc = np.hypot(d.x,d.y)
    
    
