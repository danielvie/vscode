# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 13:05:18 2019

@author: dvieira
"""

def getState():
    state = {
            "lancamento": {
                "elev": 410, "azi": 0
            }, 
            "ganhos": {
                "ganho1": 9.420, "ganho2": 0.190, "ganho3": 1.600, "ganho4": 3.680,
                "ganho5": 0.9,  # percentual GPS
                "ganho6": 1.0,  # flag ejeta
                "ganho7": -0.024, "ganho8": 1.827, "ganho9": 990.00, 
                "ganho10": 1.0, # limitador Wx
            },
            "alvo": {
                "lat": -23.126396,
                "lon": -45.813782,
                "alt": 685,
            }
        }
    
    return state