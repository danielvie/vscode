# -*- coding: utf-8 -*-

def ajusteGanhos(x, tipo = 'all'):
    if 'all' in tipo:
        return ajusteGanhos_all(x)
    elif 'gui' in tipo:
        return ajusteGanhos_gui(x)
    elif 'con' in tipo:
        return ajusteGanhos_con(x)
    elif 'bez' in tipo:
        return ajusteGanhos_bez(x)

def ajusteGanhos_all(x): 
    x_ = [0,]*7
    
    x_[0] = x[0]/200.0 + 8.00, # [3,13] N_lat
    x_[1] = x[1]/800.0 + 1.25, # [0,2.5] N_lon
    x_[2] = x[2]/400.0 + 2.5,  # [0,5] Ka
    x_[3] = x[3]/400.0 + 2.5,  # [0,5] Kw
    x_[4] = x[4]/1000.00,      # [-1,1] c1 bezier
    x_[5] = x[5]/250.00,       # [-4,4] c2 bezier 
    x_[6] = x[6]/2.0 + 1000.0, # [500,1500] distancia guiamento

    return x_

def ajusteGanhos_gui(x):
    
    x[0] = min(max(x[0],-1000.0),1000.0)
    x[1] = min(max(x[1],-1000.0),1000.0)
    
    x_ = [0, ]*2

    x_[0] = x[0]/200.0 + 8.00, # [3,13] N_lat
    x_[1] = x[1]/800.0 + 1.25, # [0,2.5] N_lon


    return x_

def ajusteGanhos_con(x):
    x_ = [0, ]*2

    x_[0] = x[0]/400.0 + 2.5,  # [0,5] Ka
    x_[1] = x[1]/400.0 + 2.5,  # [0,5] Kw

    return x_


def ajusteGanhos_bez(x):
    x_ = [0, ]*2

    x_[0] = x[0]/1000.00,      # [-1,1] c1 bezier
    x_[1] = x[1]/250.00,       # [-4,4] c2 bezier

    return x_
