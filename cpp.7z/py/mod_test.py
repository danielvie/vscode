import fg as fg_mod
import matplotlib.pyplot as plt
from time import time
from fg_utils import deg2utm, utm2deg

if __name__ == "__main__":

    fg = fg_mod.fg()

    ini = time()
    
    fg.init()

    fg.start()

    r = fg.run()


    # fg.vento = {
    #     'altitude': [ 0, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000 ], 
    #     'velocidade': [ 3, 6, 7, 17, 17, 16, 16, 13, 18, 20, 15, 16, 26, 32, 21, 17, 14, 26, 50, 37, 24, 34 ], 
    #     'azimute': [ 6290, 160, 460, 400, 530, 450, 520, 340, 420, 980, 940, 1220, 1380, 1510, 1510, 1570, 1270, 2770, 2910, 3130, 3730, 3690 ]
    # }

    

    print('\nvelocidade:')
    print(fg.vento['velocidade'])
    print('\nazimute:')
    print(fg.vento['azimute'])
    print('\naltitude:')
    print(fg.vento['altitude'])

    print('tempo : {:.2f}'.format(time() - ini))
