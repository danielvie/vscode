import fg_engine
from fg_utils import deg2utm

import numpy as np
import pandas as pd

class ModelData (object):
    def __init__(self, name, value, alias):
        self.__value = value
        self.__name  = name
        self.__alias = alias        
        
    @property
    def value(self):
        # return fg_engine.get_edtdata(self.__name)
        return self.__value

    @value.setter
    def value(self, value):
        if not np.isscalar(value):
            value_ = [0.]*41
            value_[:len(value)] = value
            value = np.array(value_)

        self.__value = value
        fg_engine.set_data(self.__name,value)

    @value.deleter
    def value(self):
        del self.__value

class fg(object):
    """ CONSTRUCTOR """
    def __init__(self):
        self.__lancamento = []
        self.__inercia = []
        self.__propelente = []
        self.__geometria = []
        self.__dados_part = []
        self.__dados_vento = []
        self.__dados_empuxo = []
        self.__controle = []
        self.__controle_on = []
        self.__vento_on = []
        self.__lmu = []
        self.__alvo = []

        self.__flags = []
        self.__used_list = dict()
        
        self.__vento_on = 1

        self.V = []

        self.access_data('Elev', 'el')
        self.access_data('Azi', 'az')

        fg_engine.start()


    """ PROPERTIES """
    @property
    def lancamento(self):
        self.__lancamento = self.get_lancamento()
        return self.__lancamento
    
    @lancamento.setter
    def lancamento(self, value):
        for v in value:
            self.set_data(v, value[v])            
    
    @property
    def lmu(self):
        self.__lmu = self.get_lmu()
        return self.__lmu
    
    @lmu.setter
    def lmu(self, value):
        self.__lmu = value
    
    @property
    def alvo(self):
        self.__alvo = self.get_alvo()
        return self.__alvo
    
    @alvo.setter
    def alvo(self, value):
        self.__alvo = value

    @property
    def controle(self):
        self.__controle = self.get_controle()
        return self.__controle
    
    @controle.setter
    def controle(self, value):
        for v in value:
            self.set_data(f'controle/{v}', value[v]) 

    @property
    def inercia(self):
        self.__inercia = self.get_inercia()
        return self.__inercia
    
    @inercia.setter
    def inercia(self, value):
        self.set_inercia(value)
        self.__inercia = self.get_inercia()
    
    @property
    def propelente(self):
        self.__propelente = self.get_propelente()
        return self.__propelente
    
    @propelente.setter
    def propelente(self, value):
        self.set_propelente(value)

    @property
    def geometria(self):
        self.__geometria = self.get_geometria()
        return self.__geometria
    
    @geometria.setter
    def geometria(self, value):
        self.set_geometria(value)

    @property
    def dados_part(self):
        self.__dados_part = self.get_dados_part()
        return self.__dados_part
    
    @dados_part.setter
    def dados_part(self, value):
        self.set_dados_part(value)
    
    @property
    def dados_vento(self):
        self.__dados_vento = self.get_dados_vento()
        return self.__dados_vento
    
    @dados_vento.setter
    def dados_vento(self, value):
        for v in value:
            self.set_data(f'vento/{v}', value[v])

    @property
    def dados_empuxo(self):
        self.__dados_empuxo = self.get_dados_empuxo()
        return self.__dados_empuxo
    
    @dados_empuxo.setter
    def dados_empuxo(self, value):
        for v in value:
            self.set_data(f'empuxo/{v}', value[v])
    
    @property
    def flags(self):
        self.__flags = self.get_flags()
        return self.__flags
    
    @flags.setter
    def flags(self, value):
        for v in value:
            self.set_data(f'flag/{v}', value[v])

    @property
    def controle_on(self):
        self.__controle_on = self.flags['controle_on']
        return self.__controle_on
    
    @controle_on.setter
    def controle_on(self, value):
        self.flags = {'controle_on':value}
    
    @property
    def vento_on(self):
        self.__vento_on = self.flags['vento_on']
        return self.__vento_on
    
    @vento_on.setter
    def vento_on(self, value):
        self.flags = {'vento_on':value}

    @property
    def vento_on(self):
        return self.__vento_on
    
    @vento_on.setter
    def vento_on(self, value):
        self.__vento_on = value
        
    """ METHODS """

    def init(self):
        fg_engine.init()

    def start(self):
        fg_engine.start()

    def access_data(self, name, alias = ''):
        if alias == '':
            alias = name

        value = self.get_data(name)
        data  = ModelData(name, value, alias)

        self.__used_list[name] = alias

        setattr(self, alias, data)

    def restart(self, value = []):
        self.init()
        self.start()

        if len(value) > 0:
            for v in value:
                self.set_data(v, value[v])
        


    def run(self):
        # guardando vento
        vento_vel = self.dados_vento['velocidade']
        if self.flags['vento_on'] == 0:
            self.dados_vento = {'velocidade': [0.]}
            pass

        # executando trajetoria        
        res = fg_engine.run()

        # restaurando vento        
        if self.flags['vento_on'] == 0:
            self.dados_vento = {'velocidade': vento_vel}

        # lendo dados simulacao
        D   = pd.DataFrame(res, columns=['t','x','y','z','vx','vy','vz','phi','theta','psi','u','v','w','p','q','r','acelx','acely','acelz','lat','lon','canard_on','canard_u1','canard_u2','canard_y1','canard_y2'])

        # ajustando saidas
        deg = 180.0/np.pi
        D['canard_u1_deg'] = D.canard_u1.mul(deg)
        D['canard_u2_deg'] = D.canard_u2.mul(deg)
        D['canard_y1_deg'] = D.canard_y1.mul(deg)
        D['canard_y2_deg'] = D.canard_y2.mul(deg)
        D['h']    = D.z.mul(-1.0)
        D['alc']  = np.hypot(D.x, D.y)
        D['vtot'] = np.sqrt(D.vx**2 + D.vy**2 + D.vz**2)
        
        # salvando voo
        self.V = D

        return D
    
    def set_data(self, name, value):
        if np.isscalar(value):
            fg_engine.set_data(name, value)
        else:
            fg_engine.set_data(name, [v for v in value])

    def get_data(self, name): 
        value = fg_engine.get_data(name)
        return value
    
    def get_lancamento(self):
        lancamento = {
            'Elev': self.get_data('Elev'),
            'Rlat': self.get_data('Rlat'),
            'Rlong': self.get_data('Rlong'),
            'Ralt': self.get_data('Ralt'),
            'Azi': self.get_data('Azi'),
            'Talt': self.get_data('Talt'),
            'Tesp': self.get_data('Tesp'),
            'Hsub': self.get_data('Hsub'),
            'Hmet': self.get_data('Hmet'),
            'Rtemp': self.get_data('Rtemp'),
            'Rde': self.get_data('Rde'),
            'Dbal': self.get_data('Dbal'),
            'Tbal': self.get_data('Tbal'),
            'Pbal': self.get_data('Pbal'),
            'Phi0': self.get_data('Phi0'),
        }
        return lancamento

    def get_inercia(self):
        inercia = {
            'Mf': self.get_data('Mf'),
            'Xf': self.get_data('Xf'),
            'Yf': self.get_data('Yf'),
            'Zf': self.get_data('Zf'),
            'Ixf': self.get_data('Ixf'),
            'Iyf': self.get_data('Iyf'),
            'Izf': self.get_data('Izf'),
            'Ixyf': self.get_data('Ixyf'),
            'Ixzf': self.get_data('Ixzf'),
            'Iyzf': self.get_data('Iyzf'),
            'Fgrot': self.get_data('Fgrot'),
            'Fog': self.get_data('Fog'),
            'Ixemp_fech': self.get_data('Ixemp_fech'),
            'Kc': self.get_data('Kc'),
            'Tabin': self.get_data('Tabin'),
            'Tabre': self.get_data('Tabre'),
            'A2': self.get_data('A2'),
            'A5': self.get_data('A5'),
            'A9': self.get_data('A9'),
            'A10': self.get_data('A10')
        }
        return inercia

    def get_propelente(self):
        propelente = {
            'Mp0': self.get_data('Mp0'),
            'Xp': self.get_data('Xp'),
            'Yp': self.get_data('Yp'),
            'Zp': self.get_data('Zp'),
            'Ixyp': self.get_data('Ixyp'),
            'Ixzp': self.get_data('Ixzp'),
            'Iyzp': self.get_data('Iyzp'),
            'Dp': self.get_data('Dp'),
            'Lp': self.get_data('Lp'),
            'Rop': self.get_data('Rop'),
            'Tb0': self.get_data('Tb0'),
            'T_trans': self.get_data('T_trans'),
            'E0': self.get_data('E0'),
            'Ye': self.get_data('Ye'),
            'Ze': self.get_data('Ze'),
            'Alfaj': self.get_data('Alfaj'),
            'Betaj': self.get_data('Betaj'),
            'Ae': self.get_data('Ae'),
            'Grot0': self.get_data('Grot0'),
            'Kcan': self.get_data('Kcan'),
        }
        return propelente

    def get_geometria(self):
        geometria = {
            'Dr': self.get_data('Dr'),
            'Lb': self.get_data('Lb'),
            'Be': self.get_data('Be'),
            'Ce': self.get_data('Ce'),
            'Fe': self.get_data('Fe'),
            'De0': self.get_data('De0'),
            'Flat': self.get_data('Flat'),
            'Fnor': self.get_data('Fnor'),
            'Retemp': self.get_data('Retemp'),
            'Wabre': self.get_data('Wabre'),
            'Dalfog0': self.get_data('Dalfog0'),
        }
        return geometria

    def get_dados_part(self):
        dados_part = {
            'Xt1': self.get_data('Xt1'),
            'Xt2': self.get_data('Xt2'),
            'Xt3': self.get_data('Xt3'),
            'Xfim': self.get_data('Xfim'),
            'Dlan': self.get_data('Dlan'),
            'Ktubo': self.get_data('Ktubo'),
            'Rt': self.get_data('Rt'),
            'Lr': self.get_data('Lr'),
            'Mir': self.get_data('Mir'),
            'Xboca': self.get_data('Xboca'),
            'Memp': self.get_data('Memp'),
            'Cemp': self.get_data('Cemp'),
            'Demp': self.get_data('Demp'),
            'Aemp': self.get_data('Aemp'),
            'Cemp0': self.get_data('Cemp0'),
            'Cemp1': self.get_data('Cemp1'),
            'Cemp2': self.get_data('Cemp2'),
            'Cemp3': self.get_data('Cemp3'),
            'Ixemp': self.get_data('Ixemp'),
            'Fcdsub': self.get_data('Fcdsub'),
            'Dsub': self.get_data('Dsub'),
            'Msub': self.get_data('Msub'),
            'Xac': self.get_data('Xac'),
            'Yac': self.get_data('Yac'),
            'Zac': self.get_data('Zac'),
        }
        return dados_part
    
    def get_flags(self):
        flags = {
            'controle_on': self.get_data('flag/controle_on'),
            'vento_on': self.vento_on
        }
        return flags

    def get_controle(self):
        controle = {
            'alvo': self.get_data('controle/alvo'),
            'dh_alvo': self.get_data('controle/dh_alvo'),
            't_canard': self.get_data('controle/t_canard'),
            'cd_subm': self.get_data('controle/cd_subm'),
            'ganhos': self.get_data('controle/ganhos'),
        }
        return controle

    def get_dados_empuxo(self):
        empuxo = {
            'Tempo': self.get_data('empuxo/Tempo'),
            'Empuxo': self.get_data('empuxo/Empuxo'),
            'Grot': self.get_data('empuxo/Grot'),
        }
        return empuxo

    def get_dados_vento(self):
        vento = {
            'altitude': self.get_data('vento/altitude'),
            'azimute': self.get_data('vento/azimute'),
            'velocidade': self.get_data('vento/velocidade'),
        }
        return vento

    def get_impacto_pos(self):
        # lendo dados 'voo'
        v = self.V

        # lendo ultimo ponto
        impacto = [v.x.values[-1], v.y.values[-1], v.h.values[-1]]

        return impacto
    
    def get_impacto_lla(self):
        deg  = 180.0/np.pi

        # lendo dados 'voo'
        v = self.V

        # lendo ultimo ponto
        impacto = [v.lat.values[-1]*deg, v.lon.values[-1]*deg, v.h.values[-1]]

        return impacto
    
    def get_impacto_utm(self):
        # lendo dados 'voo'
        la, lo, h = self.get_impacto_lla()

        # convertendo para 'utm'
        e, n, _, _ = deg2utm(la, lo)

        # lendo ultimo ponto
        impacto = [e, n, h]

        return impacto
    
    def get_lmu(self):
        deg  = 180.0/np.pi
        lanc = self.lancamento
        la   = lanc['Rlat']*deg
        lo   = lanc['Rlong']*deg
        h    = lanc['Ralt']

        (e,n,_,_) = deg2utm(la, lo)

        lmu = [e, n, h]
        return lmu
    
    def get_alvo(self):
        contr = self.controle
        la   = contr['alvo'][0]
        lo   = contr['alvo'][1]
        h    = contr['alvo'][2]

        (e,n,_,_) = deg2utm(la, lo)

        controle = [e, n, h]
        return controle