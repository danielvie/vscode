# -*- coding: utf-8 -*-
"""
Created on Tue Feb 11 14:28:54 2020

@author: dvieira
"""

import fg as fg_mod
import numpy as np
import matplotlib.pyplot as plt

o = fg_mod.fg()

if __name__ == "__main__":
    o.init()
    o.start()
    
    lancamento = {
        'Elev': 750,
        'Rlat': -0.271803565113689,
        'Rlong': -0.824044055484929,
        'Ralt': 972,
        'Azi': 3159.73490744201,
        'Talt': 971,
        'Tesp': 1e+95,
        'Hsub': 0,
        'Hmet': 972,
        'Rtemp': 30,
        'Rde': 1.04054586417798,
        'Dbal': 1,
        'Tbal': 1,
        'Pbal': 1,
        'Phi0': 0,
    }
    
    o.lancamento = lancamento
    
#    o.dados_vento = {'velocidade':[0]}
#    
#    o.tabela_vento = {
#            'altitudes': [ 0, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000 ],
#            'velocidade': [ 3, 6, 7, 17, 17, 16, 16, 13, 18, 20, 15, 16, 26, 32, 21, 17, 14, 26, 50, 37, 24, 34 ],
#            'azimute': [ 6290, 160, 460, 400, 530, 450, 520, 340, 420, 980, 940, 1220, 1380, 1510, 1510, 1570, 1270, 2770, 2910, 3130, 3730, 3690 ],
#            'flag': 1
#            }
    
    o.controle_on = 0
    r = o.run()
    plt.plot(r.alc, r.h)
    
    o.restart(lancamento)
    o.controle_on = 0
    
    r = o.run()
    plt.plot(r.alc, r.h)
    
    