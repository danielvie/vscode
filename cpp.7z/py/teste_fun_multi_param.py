# -*- coding: utf-8 -*-
"""
Created on Tue Sep 17 14:33:32 2019

@author: dvieira
"""

import numpy as np

def fun(a,b,c,d):
    return (a+b+c+d)

if __name__ == '__main__':
    
    UPPER = [6.5, 3.0, 3.0, 3.0]
    LOWER = [0.5, 0.5, 0.1, 0.1]
    x = [1,2,3,4]
    for i in range(len(UPPER)):
        if (x[i] < LOWER[i]) or (x[i] > UPPER[i]):
            return 10000000.0
    
    
