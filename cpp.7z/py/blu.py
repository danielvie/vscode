# -*- coding: utf-8 -*-
"""
Created on Wed Nov 20 15:08:16 2019

@author: dvieira
"""

import fg as fg_mod
import pandas as pd
import matplotlib.pyplot as plt
from time import time


fg = fg_mod.fg()

if __name__ == '__main__':
    
    ini = time()
    
    fg.init()
    fg.start()
    fg.controle_on = 1
    
    fg.lancamento = {
        'Elev': 750,
        'Azi': 2932.77838914613,
        'Rlat': -0.271594482101657,
        'Rlong': -0.825247196238898,
        'Ralt': 899,
        'Talt': 971,
        'Tesp': 1e+95,
        'Hsub': 0,
        'Hmet': 899,
        'Rtemp': 34,
        'Rde': 1.02756197152245,
        'Dbal': 1,
        'Tbal': 1,
        'Pbal': 1,
        'Phi0': 0,
    }
    
    fg.controle = {
        'alvo': [-15.8638066989881, -47.2028379635807, 971],
        'ganhos': [0.9, 500.0, 33120.0, 3.5, -100.0, 4.2, 750.0]
    }
    
    r = fg.run()

    print('tempo: {:.2f}'.format(time() - ini))

    plt.plot(r.t, r.canard_y1_deg)
    
    r2 = pd.read_pickle('bla.pkl')
    plt.plot(r2.t, r2.canard_y1_deg)
    
    plt.figure()
    plt.plot(r.t, r.canard_y1_deg - r2.canard_y1_deg)
    
    