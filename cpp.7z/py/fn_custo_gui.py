# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:47:47 2019

@author: dvieira
"""
import fg
import numpy as np
import pandas as pd
from fn_ajuste_ganhos import ajusteGanhos

def rodaCusto_gui_helper(state):
    fg.init()
    fg.setLancamento(state)
    fg.setGanhos(state)
    fg.setAlvo(state)    
    fg.start()
    
    lat  = 0.0
    lon  = 0.0
    can  = []
    elon = []
    deg  = 180.0/3.1415926535897932384

    while not fg.getFim():
        # passo de simulacao
        o = fg.stepLog()

        # posicao
        lat = o['lat']
        lon = o['lon']

        #  canard
        t = o['t']
        u = o['canard_u1']*deg
        erro_lon = fg.getLogControle()['erro_lon']

        if u != 0.0:
            can.append([t,u])
            elon.append([t,erro_lon])

    # transformando em dataframe
    can  = pd.DataFrame(can, columns=['t','u'])
    elon = pd.DataFrame(elon, columns=['t','e'])
    
    # mantendo apenas ultimos 10 segundos apenas
    # dfim = can.t.values[-1]
    # can  = can[can.t > (dfim - 10.0)]
    
    dfim = elon.t.values[-1]
    elon = elon[elon.t > (dfim - 15.0)]

    erro_lon = np.trapz(elon.e.abs(), elon.t)

    # calculo rms
    rms_canard = 0.0
    for u in can.u:
        rms_canard += u**2
    
    rms_canard = np.sqrt(rms_canard/len(can.u))
    
    # print("erro_lon: {:.2f}".format(erro_lon))
    # print("rms_can : {:.2f}".format(rms_canard))

    alvo = fg.getControle()['alvo']
    raio_terra = 6371000
    
    # distancia alvo
    dist_lat = (lat - alvo['lat']*np.pi/180.0)*raio_terra
    dist_lon = (lon - alvo['lon']*np.pi/180.0)*raio_terra
    
    
    # custo total
    # custo = dist_lat**2 + dist_lon**2 + rms_canard**2
    custo = dist_lat**2 + dist_lon**2 + erro_lon
    return custo

def rodaCusto_gui(x):
    state = {
        "lancamento": {
            'Elev': 461.5,
            'Rlat': -0.407111519925235, 
            'Rlong': -0.799622322463303, 
            'Ralt': 739.0,
            'Azi': 3076.1,
            'Talt': 739.0,
            'Tesp': 1e+95,
            'Hsub': 0.0, 
            'Hmet': 739.0,
            'Rtemp': 25.3, 
            'Rde': 1.05588190060624, 
            'Dbal': 1.0, 
            'Tbal': 1.0, 
            'Pbal': 1.0, 
            'Phi0': 0.0
        }, 
        "ganhos": {
            "ganho1": 9.420, "ganho2": 0.190, "ganho3": 1.600, "ganho4": 3.680,
            "ganho5": 0.9,  # percentual GPS
            "ganho6": 3.0,  # ajuste de precessao
            "ganho7": -0.024, "ganho8": 1.827, "ganho9": 990.00, 
            "ganho10": 2.0, # limitador Wx
        },
        "alvo": {
            "lat": -23.541037078731,
            "lon": -45.7873265255656,
            "alt": 739.0,
        }
    }
    
    x_ = [x[0], x[1], 4.8552, 0.8758, 0.587176, 2.582872, 1496.1504]
    xx = ajusteGanhos(x_)
    
    state['ganhos']['ganho1']  = xx[0][0] # [0,10] N_lat
    state['ganhos']['ganho2']  = xx[1][0] # [0,10] N_lon
    state['ganhos']['ganho3']  = xx[2][0] # [0,10] Ka
    state['ganhos']['ganho4']  = xx[3][0] # [0,10] Kw
    state['ganhos']['ganho5']  = xx[4][0] # [-1,1] c1 bezier
    state['ganhos']['ganho8']  = xx[5][0] # [-2,2] c2 bezier 
    state['ganhos']['ganho9']  = xx[6][0] # [750,1250] distancia guiamento
    #state['ganhos']['ganho10'] = xx[7][0] # [0.5,3.0] faixa de rotacao

    mils = 0.05625

    # state['lancamento']['Elev'] = state['lancamento']['Elev'] + 2/mils
    # state['lancamento']['Azi'] = state['lancamento']['Azi'] - 2/mils
    # custo1 = rodaCusto_gui_helper(state)

    # state['lancamento']['Elev'] = state['lancamento']['Elev'] + 2/mils
    # state['lancamento']['Azi'] = state['lancamento']['Azi'] + 2/mils
    # custo2 = rodaCusto_gui_helper(state)

    state['lancamento']['Elev'] = state['lancamento']['Elev'] - 2/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] + 2/mils
    custo3 = rodaCusto_gui_helper(state)

    state['lancamento']['Elev'] = state['lancamento']['Elev'] - 2/mils
    state['lancamento']['Azi'] = state['lancamento']['Azi'] - 2/mils
    custo4 = rodaCusto_gui_helper(state)

    # custo = np.sqrt(custo1**2 + custo2**2 + custo3**2 + custo4**2)
    custo = np.sqrt(custo3**2 + custo4**2)
    return custo
