# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 12:49:46 2019

@author: dvieira
"""

import time
from fn_ajuste_ganhos import ajusteGanhos

# 'a_resultado.txt'
def salvaHOF(addr, hof, seed, tempo, tipo = 'all'):
    with open(addr,'a+') as f:
        f.write('----------------------------\n')
        f.write('seed: {:d}\n\n'.format(seed))
        f.write('tempo de simulacao: {}\n\n'.format(tempo))
        f.write('hof(i):\n')
        
        # data
        data = time.localtime()
        data_txt = 'data: {}/{}/{}; hora: {}:{}:{}\n\n'.format(data.tm_mday,data.tm_mon,data.tm_year,data.tm_hour,data.tm_min,data.tm_sec)
        f.write(data_txt)
		
        for i,H in enumerate(hof):
            v = '{:d}, '.format(i)
            for h in H:
                v = '{}{:.6f}, '.format(v,h)
            v = v+' fitness: {:.2f}\n'.format(H.fitness.values[0])
            f.write(v)