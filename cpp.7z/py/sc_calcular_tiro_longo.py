import fg as fg_mod
import matplotlib.pyplot as plt
from time import time
from fg_utils import deg2utm, utm2deg
from numpy import pi, arctan2 as atan2
from numpy.linalg import norm
import numpy as np

fg = fg_mod.fg()

def calculo_desvios(impacto_utm, alvo_utm, lmu_utm):
    alvo_utm[2]    = 0.0
    lmu_utm[2]     = 0.0
    
    vetor_alvo     = np.subtract(alvo_utm, lmu_utm)
    vetor_impacto  = np.subtract(impacto_utm, lmu_utm)

    dist_alvo      = np.linalg.norm(vetor_alvo)
    desvio_alcance = np.dot(vetor_alvo, vetor_impacto)/dist_alvo - dist_alvo

    desvio_lateral = np.cross(vetor_impacto, vetor_alvo)[2]/dist_alvo

    return desvio_alcance, desvio_lateral


def calcular_tiro_x(data, dist_frente_alvo = 0.0, ab = [150.0, 1000.0]):
    # inicializando modelo com dados
    m2d     = 0.05625
    d2m     = 1/m2d
    r2d     = 180.0/pi
    knot2ms = 0.514444
        
    # POSICAO LMU, ALVO
    lmu  = np.array(data['lmu_utm'])
    alvo = np.array(data['alvo_utm'])

    # ENCONTRANDO ALVO 'x' KM PARA FRENTE
    aux  = (alvo-lmu)[0:2]
    dist = np.linalg.norm(aux)

    alvo[0:2] = lmu[0:2] + aux/dist*(dist + dist_frente_alvo)

    # TEMPERATURA E PRESSAO
    met_temperatura = data['temp'] # celcius
    met_pressao     = data['pressao'] # mbar
    met_densidade   = met_pressao*100.0/287.058/(met_temperatura + 273.15)

    # VENTO SUPERFICIE
    vento_sup_vel   = data['vento_sup_vel_knots']
    vento_sup_azi   = data['vento_sup_azi']
    
    # MET
    altitude        = [ 0, 200, 500, 1000, 1500, 2000, 2500, 3000, 3500, 4000, 4500, 5000, 6000, 7000, 8000, 9000, 10000, 11000, 12000, 13000, 14000, 15000 ]
    
    velocidade      = data['met_vel_knot']
    azimute         = data['met_azi']

    velocidade[0]   = vento_sup_vel
    azimute[0]      = vento_sup_azi

    velocidade      = np.multiply(velocidade,knot2ms)
    azimute         = np.multiply(azimute,m2d)

    fg.vento_on     = data['flag_vento']

    velocidade      = np.multiply(velocidade,fg.vento_on)

    # CONFIGURANDO STATE
    fg.vento = {
        'altitude': altitude,
        'velocidade': velocidade,
        'azimute': azimute
    }
    
    # IMPRIMINDO INFORMACOES INICIAIS
    vetor_alvo = (alvo - lmu)[0:2]
    dgt        = atan2(vetor_alvo[0],vetor_alvo[1])*r2d*d2m
    
    if (dgt < 0.0):
        dgt = dgt + 6400.0
    
    
    print('-------------------------------')
    print('alcance nominal : {:.1f} m'.format(norm(vetor_alvo)))
    print('dgt             : {:.1f} mils'.format(dgt))
    print('-------------------------------')

    # CONFIGURACAO DO STATE
    
    # lmu posicao (utm)
    lmu_e    = lmu[0]
    lmu_n    = lmu[1]
    lmu_alt  = lmu[2]

    # alvo x (lla / deg)
    alvo_e   = alvo[0]
    alvo_n   = alvo[1]
    alvo_alt = alvo[2]
    
    # convertendo para latlon
    zona_utm = data['alvo_zona']
    hemis    = data['hemis']
    
    lmu_lat,lmu_lon   = utm2deg(lmu_e, lmu_n, zona_utm, hemis)
    alvo_lat,alvo_lon = utm2deg(alvo_e, alvo_n, zona_utm, hemis)

    lancamento0 = {
        'Rtemp': met_temperatura,
        'Rde': met_densidade,
        'Rlat': lmu_lat/r2d,
        'Rlong': lmu_lon/r2d,
        'Ralt': lmu_alt,
        'Hmet': lmu_alt,
        'Talt': alvo_alt,
        'Azi': dgt
    }

    controle0 = {
        'alvo': [alvo_lat, alvo_lon, alvo_alt]
    }
    
    flags0 = {
        'controle_on': 0.
    }

    # BUSCA BINARIA
    a = ab[0]
    b = ab[1]

    correcao_azi  = 0.0
    azi_corrigido = dgt
    
    alvo_utm    = [alvo_e, alvo_n, alvo_alt]
    lmu_utm     = [lmu_e, lmu_n, lmu_alt]
    
    for i in range(15):
        # inicializando modelo
        fg.init()
        fg.start()

        # carregando dados
        fg.lancamento = lancamento0
        fg.controle   = controle0
        fg.flags      = flags0

        # CALCULO DE X
        x = (a + b)/2.0

        # atualizando apontamento
        fg.lancamento = {
            'Elev': x,
            'Azi': azi_corrigido
        }
        
        # SIMULACAO
        r = fg.run()
        
        # AVALIACAO
        
        # calculando desvios
        impacto_utm = fg.get_impacto_utm()
                
        desvio_alcance, desvio_lateral = calculo_desvios(impacto_utm, alvo_utm, lmu_utm)
        
        lanc = fg.lancamento
        txt_elev   = 'elev, min, max, res      : ({:.1f}, {:.1f}, {:.1f}, {:.1f})'.format(x, a, b, b-a)
        txt_azi    = 'azi                      : ({:.1f})'.format(lanc['Azi'])
        txt_desvio = 'desvio alcance / lateral : ({:.1f}, {:.1f})'.format(desvio_alcance, desvio_lateral)
        
        print('({})'.format(i+1))
        print('{}'.format(txt_elev))
        print('{}'.format(txt_azi))
        print('{}'.format(txt_desvio))
        print(' ')

        # CONDICAO DE SAIDA
        if np.all(np.abs([desvio_alcance, desvio_lateral]) < 1.0):
            print('condicao de saida acionado.');
            break;
        
        if (desvio_alcance < 0.0):
            a = x
        else:
            b = x
        
        alcance       = np.linalg.norm( np.subtract(impacto_utm[0:2], lmu_utm[0:2]) )
        correcao_azi  = -desvio_lateral/alcance*1000.0
        
        azi_corrigido = fg.lancamento['Azi'] + correcao_azi

    return r


if __name__ == "__main__":

    ini = time()

    fg.init()
    fg.start()

    data = {
        'lmu_utm': [255137.0, 8278290.0, 899.0],
        'alvo_utm': [263769.0, 8246145.0, 971.0],
        'alvo_zona': 23,
        'hemis': 'S',
        'temp': 34.0,
        'pressao': 906.0,
        'vento_sup_vel_knots': 6.0,
        'vento_sup_azi': 500.0,
        'flag_vento': 1,
        'met_vel_knot': [ 2, 5, 7, 6, 8, 9, 7, 3, 2, 4, 7, 9, 10, 4, 8, 7],
        'met_azi': [ 380, 660, 870, 420, 110, 350, 430, 3230, 2600, 900, 460, 6170, 6370, 370, 6020, 1080]
    }
    
#    r = calcular_tiro_x(data, 1300.0, [600, 900])
    r = calcular_tiro_x(data, 0.0, [600, 900])

#    elev = fg.lancamento['Elev']

#    r = calcular_tiro_x(data, 0.0, [elev - 100.0, elev])

#    print('tempo: {:.1f}'.format(time() - ini))
    